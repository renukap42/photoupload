import axios from 'axios';


const API_Img = 'http://localhost:8080/PhotoUploadReact/FileUpload';

class ApiService {

    FileUpload() {
        return axios.post('http://localhost:8080/PhotoUploadReact/FileUpload');
    }

    
}

export default new ApiService();