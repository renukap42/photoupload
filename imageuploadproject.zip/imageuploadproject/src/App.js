import React from 'react';

import './App.css';
import {BrowserRouter, NavLink, Route, Switch} from 'react-router-dom'
import ApiService from "./ApiService";
import Demo from './Demo';



function App() {
  return (
    <div className="App">

  
    <h1 style={{backgroundColor:"#2c5282", color:"white"}}><center>Gallary</center></h1>

   
   <Demo/>
<div>
<footer style={{backgroundColor:"#2c5282",color:"white"}}>
   <center><h2>Fullstack Challenge-2020</h2>  
   </center>
 </footer>
 </div>
 </div>
  );
}

export default App;
