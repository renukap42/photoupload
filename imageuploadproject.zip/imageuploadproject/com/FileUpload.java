package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dbDao.DaoUtil;




@WebServlet("/FileUpload")
public class FileUpload extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public FileUpload() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	

	
	
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	  
      response.setContentType("text/json");
	  response.addHeader("Access-Control-Allow-Origin", "*");
//	  PrintWriter out = response.getWriter();
	  
		System.out.println("welcome servlet");
		
		
		
		Connection con=DaoUtil.getConnect();
		try {
			Statement st=con.createStatement();
			int n=st.executeUpdate("insert into images(img)values(?)");
			System.out.println("no.of record="+n);
		
		
  }
		catch (SQLException e) {
			
			e.printStackTrace();
		}
}
}