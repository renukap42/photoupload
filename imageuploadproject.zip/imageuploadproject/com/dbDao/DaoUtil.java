package com.dbDao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



public class DaoUtil {
	private static String driver="com.mysql.cj.jdbc.Driver";
	private static String url="jdbc:mysql://localhost:3306/renu";
	private static String user="root";
	private static String pass="root";
	private static Connection con=null;
	public static Connection getConnect()
	{
		try
		{
			
			try {
				Class.forName(driver);
			} 
			
			catch (ClassNotFoundException e) {
				
				e.printStackTrace();
			}
			con=DriverManager.getConnection(url,user,pass);
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		return con;

 	}

}
